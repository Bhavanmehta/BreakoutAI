# Handoff: BreakoutAI Website Redesign

## Overview
Redesign of the BreakoutAI web app (https://breakout-ai-ochre.vercel.app / github.com/Bhavanmehta/BreakoutAI) — a pre-breakout stock scanner for Indian equities. This package covers four finalized pages:
1. **Home / Radar** (design id 3a) — the daily scanner terminal
2. **Stock Deep Dive** (4a) — full analysis for one stock (opened via "Open full analysis" / "AI Deep Dive")
3. **Backtest & Performance** (4b) — strategy scorecard and full call log
4. **Marketing landing** (5a) — logged-out visitor page

## About the Design Files
The file `BreakoutAI Redesign.dc.html` is a **design reference created in HTML** — a prototype showing intended look and behavior, not production code to copy directly. Recreate these designs in the target codebase's existing environment (the BreakoutAI repo — React/Next.js on Vercel) using its established patterns. All screens are static mockups with sample data; wire them to the app's real data sources.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy tone are final. Recreate pixel-perfectly. Sample data (tickers, prices, scores) is illustrative — replace with live data.

## Design Tokens
Fonts (Google Fonts):
- UI: `Instrument Sans` 400/500/600/700
- Numerals, tickers, labels: `JetBrains Mono` 400/500/700 — ALL numbers, prices, scores, and uppercase micro-labels use the mono font.

Colors:
- Page bg: `#0d1319` (app), `#0a0e13` (landing)
- Header/topbar bg: `#0a0f14`
- Card bg: `#10171f`; nested/inner card: `#0d141b`; highlighted row/card: `#121b24`; rail bg: `#0b1016`
- Borders: `#1c2733` (default), `#161f29` (section dividers), `#1f2a36` (buttons/chips), `#223140` (row hover), `#2a4a42` (accent border), `#3a2a30` (bear/red border)
- Text: `#e8edf2` (primary), `#c3ced8` (body), `#8b9aa8` (secondary), `#5b6b7a` (muted/labels)
- Accent mint: `#3fc1ab` (hover lift `#5cd8c2`); on-accent text `#06110f`
- Amber (mid conviction): `#e3b34c`; Red (risk/negative): `#e8788a`
- Bull-case card bg `#0f1a17`; bear-case card bg `#1a1114`

Radii: cards 10–16px, buttons 8–10px, chips 16px (pill), badges 5–6px.
Micro-label style: `font: 500 10px JetBrains Mono; letter-spacing: .14em; color: #5b6b7a; uppercase`.
Conviction color rule: score ≥ 70 → mint, 40–69 → amber, negative/risk → red.

## Animations (all pages)
- `riseIn`: fade + translateY(14px→0), .5s, staggered ~70–100ms per item — cards, rows, sections on load
- `growBar`: scaleX(0→1) from left, 1s cubic-bezier(.2,.8,.2,1) — all conviction/progress bars
- `livedot`: opacity pulse 1.6s — LIVE badge dot
- `tape`: translateX(0→-50%) 28s linear infinite — index ticker (content duplicated 2× for seamless loop)
- `sweep`: conic-gradient rotation 6s linear — radar sweep (landing hero)
- `blip`: expanding box-shadow ring 2.4s — radar blips
- `coil`: scale pulse 1→.86→1, 2.2s — featured coil dial
- `dash`: SVG stroke-dashoffset draw-in 2s — equity curve
- Count-up on load (1.4s, ease-out cubic) for NIFTY price and scan-confidence % (fallback: snap to final value after 1.6s if rAF throttled)

## Screens

### 1. Home / Radar (3a)
Top bar (bg #0a0f14): logo mark (30px mint rounded square, "B"), "BreakoutAI / Radar", INDIA/US segmented toggle, date chip "16 Jul 2026 · EOD", spacer, NIFTY price block (count-up), LIVE pill.
Ticker tape (28s loop): index + stock quotes in mono 12px.
Verdict band: "12 PRIMED" outline badge, "Breadth improving" chip, SCAN CONFIDENCE bar (74%, animated); 27px headline with mint highlight span; 3 sub-bullets.
Filter toolbar — ONE line: chips [Primed only (active), VCP coils, Near 52w high] · divider · "Fundamentals ▾" button with mint count badge (2) · "Sector: All ▾" · "Universe: Midcap ▾" (options: Nifty 50 / Large cap / Midcap / Smallcap / All) · inline active-criteria text "P/E < 60 · EPS growth > 20% Clear" · right: "Sorted by conviction ▾".
Table columns: `170px 1fr 130px 110px 90px 90px 90px 120px` = STOCK | CONVICTION (animated bar + number) | SETUP (outline chip) | PRICE | DAY | TO PIVOT | COIL (38px conic-gradient donut dial, fill = 1−VCP, value inside) | SCORE (Δ) right-aligned, e.g. "88 (+4)".
SCORE hover tooltip: 250px dark panel (#0a0f14, mint border), "POINTS TODAY" label, +N lines in mint / −N lines in red (e.g. "+2 Coil tightened 0.48→0.41"). Hovered row must get z-index above siblings (each row animates and creates a stacking context).
First row (KAYNES) renders expanded: highlighted card containing THE READ (narrative with mint/red key prices) beside KEY LEVELS ruler (see below), then actions: [Open full analysis →] primary mint, [+ Track], [AI Deep Dive] outline; right-aligned disclaimer "Educational only, not investment advice".
KEY LEVELS ruler: horizontal 4px track; mint gradient zone between support and pivot; tick marks + labels for support (₹5,610 · 2×), current price (mint triangle pointer above), pivot (₹5,890 · 3×, mint), next resistance (₹6,120).
Footer link: "Show all 42 scanned →".

### 2. Stock Deep Dive (4a)
Top bar: breadcrumb "Radar / KAYNES", actions right: [+ Track] outline, [Set alert at ₹5,890] primary.
Two-column grid `1fr 360px`; right column is the AI rail (bg #0b1016).
Main column, in order:
- Title row: "KAYNES" 44px mono + meta "Kaynes Technology · Capital Goods · Midcap"; right: price ₹5,842 +1.4%.
- Verdict card (highlighted, mint border): 64px conic donut with 88; "PRIMED — tightest coil on the radar" + 2-line summary with trigger/void levels.
- Two cards: SCORE BREAKDOWN (5 animated bars: Coil tightness 28/30, Volume dry-up 24/25, Pivot quality 17/20, Relative strength 12/15, Delivery volume 7/10 amber) | FUNDAMENTALS (2-col key/value: P/E 61.2 red, EPS growth +38%, ROE 17.4%, Debt/Equity 0.21, Sales growth +31%, Mkt cap; footer note "Passes 4 of 5 of your fundamental filters — P/E 61 is above your 60 cap").
- KEY LEVELS & PLAN card: same ruler as home (stop −4.0%, entry pivot, target 1 +3.9%) + footer row: Risk/reward 1:2.1, suggested size at 1% risk.
- BULL CASE vs BEAR CASE cards side by side: green-tinted (#0f1a17/#2a4a42) with "72% weight", red-tinted (#1a1114/#3a2a30) with "28% weight"; 4 bullet lines each.
- VCP CONTRACTIONS card (bar chart of 4 shrinking legs T1 −18% → T4 −2.8%, last bar solid mint) | OWNERSHIP · QOQ card (4 bars: FII 18.4% ▲2.1 mint, DII 13.1% ▲0.6 mint, Promoter 57.8% — grey, Retail 10.7% ▼2.7 red; note "Smart money accumulating while retail exits").
- PREVIOUS SCENARIOS table: DATE | SETUP | COIL | RESULT | DURATION for prior KAYNES coils.
- NEWS & CATALYSTS: date + tag chip (ORDER mint / BROKER grey / EVENT amber) + one-line text.
AI rail: label "AI DEEP DIVE"; chat bubbles (assistant = card style, user = #1d2a35 right-aligned); suggested question chips ("What breaks this setup?", "Compare with CGPOWER"); input placeholder "Ask anything about KAYNES…".

### 3. Backtest & Performance (4b)
Top bar: title, 3M/6M/1Y/All segmented toggle (1Y active), right label "EVERY CALL LOGGED · NOTHING DELETED".
Stat strip (5 cards): CALLS 214, BREAKOUT RATE 58% mint, AVG WINNER +6.8% mint, AVG LOSER −3.6% red, EXPECTANCY +1.9% mint.
Grid `1fr 380px`: EQUITY CURVE card (SVG polylines, radar line mint 2px with draw-in animation, benchmark grey; legend "— Radar +34.2% / — Benchmark +11.8%"; month axis) | OUTCOME MIX card (stacked horizontal bar 58/17/25: mint / dark mint #2a6b5e / dark red #3a2a30; legend rows; expectancy footnote).
Call log table: DATE | STOCK | CALL | ENTRY | EXIT | RESULT (colored) | DURATION; losers shown honestly; footer "Full log · 214 calls →".

### 4. Marketing landing (5a)
Nav: logo, links (Product, Track record, Pricing), [Sign in] outline, [Start free] primary.
Hero grid `1fr 460px`: left — LIVE pill "SCANNING 500+ NSE STOCKS NIGHTLY", 52px headline "Find stocks coiling for a breakout — before they move." (mint span), subcopy, CTAs [See tonight's radar →] + [View track record], microcopy "Free for 14 days · No card · Educational, not investment advice"; right — animated radar (420px, concentric rings, rotating conic sweep, pulsing blips labeled with ticker · score).
Ticker tape (same component as home).
HOW IT WORKS: 3 cards — 01 · SCAN / 02 · SCORE / 03 · PLAN (copy in the design file).
TRACK RECORD section: framed card reusing the 5 backtest stats; heading "Every call logged. Losers included."; link to backtest page.
Pricing: 2 cards max-width 820px — Radar ₹0 (3 bullets) | Pro ₹999/mo, mint-bordered with "EVERYTHING" tag, 4 bullets, [Start 14-day trial] primary.
Footer: disclaimer "Educational tool — not SEBI-registered investment advice." + Terms/Privacy/Contact.

## Interactions & Behavior
- Row hover: bg #121b24 + border #223140; chips/buttons hover: border-color → mint; primary button hover: bg → #5cd8c2.
- Score tooltip on hover of the SCORE cell (see above).
- Filter dropdowns (Fundamentals, Sector, Universe) open panels with the chip options; active fundamental filters render as inline text with a Clear action; Fundamentals button shows an active-count badge.
- Expanded row: clicking any table row expands it in place to the KAYNES-style detail (read + ruler + actions); "Open full analysis" navigates to the Deep Dive page.
- Landing radar: decorative, non-interactive.

## State Management
- Radar page: filter state (setup chips, fundamentals criteria, sector, universe), sort key, expanded-row id, market status (live/EOD).
- Deep dive: ticker param, chat thread state, alert/track toggles.
- Backtest: period toggle.

## Assets
No image assets — everything is CSS/SVG. Fonts loaded from Google Fonts.

## Files
- `BreakoutAI Redesign.dc.html` — all four screens, newest at top: section 5 = landing (5a), section 4 = deep dive (4a) + backtest (4b), section 3 = home/radar (3a). Open in a browser; sample data lives in the embedded script at the bottom of the file.
